//*********************************************************************
//Gestion des caract�res accentu�s
//P�rim�tre limit� aux 15 caract�res sp�ciaux de la langue fran�aise
// � � � � � � � � � � � � � � �
//*********************************************************************
#ifndef Accents_h
#define Accents_h

#include <stdint.h>

class Accents_c
{
  public:
    char* Supprimer(char source[], char destination[], uint8_t taille_max);
    char* Supprimer(char source_a_modifier[]);
    char* Transcoder_ASCII(char source[], char destination[], uint8_t taille_max);
    char* Transcoder_ASCII(char source_a_modifier[]);
    char* Transcoder_UNICODE(char source[], char destination[], uint8_t taille_max);
    char* Transcoder_UNICODE(char source_a_modifier[]);
    char* Transcoder_UTF8(char source[], char destination[], uint8_t taille_max);
    char* Transcoder_HTML(char source[], char destination[], uint8_t taille_max);
};

extern Accents_c Accents;

#endif
