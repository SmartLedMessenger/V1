//*********************************************************************
//Gestion des caract�res accentu�s
//P�rim�tre limit� aux 15 caract�res sp�ciaux de la langue fran�aise
// � � � � � � � � � � � � � � �
//*********************************************************************
#include "Accents.h"

const uint8_t Accents_format_sans    = 0;
const uint8_t Accents_format_ASCII   = 1;
const uint8_t Accents_format_UNICODE = 2;
const uint8_t Accents_format_UTF8    = 3;
const uint8_t Accents_format_HTML    = 4;

char* Transcoder(uint8_t source[], uint8_t destination[], uint8_t format_cible, uint8_t taille_max)
{
  const uint8_t Accents_id_agrave =  1; // �
  const uint8_t Accents_id_acirc  =  2; // �
  const uint8_t Accents_id_auml   =  3; // �
  const uint8_t Accents_id_ccedil =  4; // �
  const uint8_t Accents_id_egrave =  5; // �
  const uint8_t Accents_id_eacute =  6; // �
  const uint8_t Accents_id_ecirc  =  7; // �
  const uint8_t Accents_id_euml   =  8; // �
  const uint8_t Accents_id_icirc  =  9; // �
  const uint8_t Accents_id_iuml   = 10; // �
  const uint8_t Accents_id_ocirc  = 11; // �
  const uint8_t Accents_id_ouml   = 12; // �
  const uint8_t Accents_id_ugrave = 13; // �
  const uint8_t Accents_id_ucirc  = 14; // �
  const uint8_t Accents_id_uuml   = 15; // �

  const uint8_t Accents_ASCII_agrave = 0x85; // �
  const uint8_t Accents_ASCII_acirc  = 0x83; // �
  const uint8_t Accents_ASCII_auml   = 0x84; // �
  const uint8_t Accents_ASCII_ccedil = 0x87; // �
  const uint8_t Accents_ASCII_egrave = 0x8a; // �
  const uint8_t Accents_ASCII_eacute = 0x82; // �
  const uint8_t Accents_ASCII_ecirc  = 0x88; // �
  const uint8_t Accents_ASCII_euml   = 0x89; // �
  const uint8_t Accents_ASCII_icirc  = 0x8c; // �
  const uint8_t Accents_ASCII_iuml   = 0x8b; // �
  const uint8_t Accents_ASCII_ocirc  = 0x93; // �
  const uint8_t Accents_ASCII_ouml   = 0x94; // �
  const uint8_t Accents_ASCII_ugrave = 0x97; // �
  const uint8_t Accents_ASCII_ucirc  = 0x96; // �
  const uint8_t Accents_ASCII_uuml   = 0x81; // �

  const uint8_t Accents_UNICODE_agrave = 0xe0; // �
  const uint8_t Accents_UNICODE_acirc  = 0xe2; // �
  const uint8_t Accents_UNICODE_auml   = 0xe4; // �
  const uint8_t Accents_UNICODE_ccedil = 0xe7; // �
  const uint8_t Accents_UNICODE_egrave = 0xe8; // �
  const uint8_t Accents_UNICODE_eacute = 0xe9; // �
  const uint8_t Accents_UNICODE_ecirc  = 0xea; // �
  const uint8_t Accents_UNICODE_euml   = 0xeb; // �
  const uint8_t Accents_UNICODE_icirc  = 0xee; // �
  const uint8_t Accents_UNICODE_iuml   = 0xef; // �
  const uint8_t Accents_UNICODE_ocirc  = 0xf4; // �
  const uint8_t Accents_UNICODE_ouml   = 0xf6; // �
  const uint8_t Accents_UNICODE_ugrave = 0xf9; // �
  const uint8_t Accents_UNICODE_ucirc  = 0xfb; // �
  const uint8_t Accents_UNICODE_uuml   = 0xfc; // �

  const uint8_t Accents_HTML_cle       = 0x26; // &

  const uint8_t Accents_UTF8_cle       = 0xc3;

  uint8_t is, id, s, carspe, a, b, c, d, e, let, accent;

  is=0;
  id=0;

  s = source[is];
  while (s)
  {
    carspe = 0;
    if (s > 159) // Unicode & UTF8
    {
      if (s == Accents_UTF8_cle)
      {
        a = source[is+1] | 0b01000000; // Unicode = UTF8 + 64
      }
      else
      {
        a = s;
      }
      switch (a)
      {
        case Accents_UNICODE_agrave : carspe = Accents_id_agrave; break;
        case Accents_UNICODE_acirc  : carspe = Accents_id_acirc;  break;
        case Accents_UNICODE_auml   : carspe = Accents_id_auml;   break;
        case Accents_UNICODE_ccedil : carspe = Accents_id_ccedil; break;
        case Accents_UNICODE_egrave : carspe = Accents_id_egrave; break;
        case Accents_UNICODE_eacute : carspe = Accents_id_eacute; break;
        case Accents_UNICODE_ecirc  : carspe = Accents_id_ecirc;  break;
        case Accents_UNICODE_euml   : carspe = Accents_id_euml;   break;
        case Accents_UNICODE_icirc  : carspe = Accents_id_icirc;  break;
        case Accents_UNICODE_iuml   : carspe = Accents_id_iuml;   break;
        case Accents_UNICODE_ocirc  : carspe = Accents_id_ocirc;  break;
        case Accents_UNICODE_ouml   : carspe = Accents_id_ouml;   break;
        case Accents_UNICODE_ugrave : carspe = Accents_id_ugrave; break;
        case Accents_UNICODE_ucirc  : carspe = Accents_id_ucirc;  break;
        case Accents_UNICODE_uuml   : carspe = Accents_id_uuml;   break;
      }
      if (carspe && (s == Accents_UTF8_cle))
      {
        is++;
      }
    }
    else
    {
      if (s > 128) // ASCII
      {
        switch (s)
        {
          case Accents_ASCII_agrave : carspe = Accents_id_agrave; break;
          case Accents_ASCII_acirc  : carspe = Accents_id_acirc;  break;
          case Accents_ASCII_auml   : carspe = Accents_id_auml;   break;
          case Accents_ASCII_ccedil : carspe = Accents_id_ccedil; break;
          case Accents_ASCII_egrave : carspe = Accents_id_egrave; break;
          case Accents_ASCII_eacute : carspe = Accents_id_eacute; break;
          case Accents_ASCII_ecirc  : carspe = Accents_id_ecirc;  break;
          case Accents_ASCII_euml   : carspe = Accents_id_euml;   break;
          case Accents_ASCII_icirc  : carspe = Accents_id_icirc;  break;
          case Accents_ASCII_iuml   : carspe = Accents_id_iuml;   break;
          case Accents_ASCII_ocirc  : carspe = Accents_id_ocirc;  break;
          case Accents_ASCII_ouml   : carspe = Accents_id_ouml;   break;
          case Accents_ASCII_ugrave : carspe = Accents_id_ugrave; break;
          case Accents_ASCII_ucirc  : carspe = Accents_id_ucirc;  break;
          case Accents_ASCII_uuml   : carspe = Accents_id_uuml;   break;
        }
      }
      else
      {
        if (s == Accents_HTML_cle) // HTML
        {
          let = 0;
          a = source[is+1];
          switch (a)
          {
            case (uint8_t) 'a' : let =  8; break;
            case (uint8_t) 'c' : let = 16; break;
            case (uint8_t) 'e' : let = 24; break;
            case (uint8_t) 'i' : let = 32; break;
            case (uint8_t) 'o' : let = 40; break;
            case (uint8_t) 'u' : let = 48; break;
          }
          if (let)
          {
            a = source[is+2];
            b = source[is+3];
            c = source[is+4];
            d = source[is+5];
            e = source[is+6];
            accent = 0;
            if ((a=='g') && (b=='r') && (c=='a') && (d=='v') && (e=='e'))
            {
              accent = 1;
            }
            if ((a=='c') && (b=='i') && (c=='r') && (d=='c'))
            {
              accent = 2;
            }
            if ((a=='u') && (b=='m') && (c=='l'))
            {
              accent = 3;
            }
            if ((a=='c') && (b=='e') && (c=='d') && (d=='i') && (e=='l'))
            {
              accent = 4;
            }
            if ((a=='a') && (b=='c') && (c=='u') && (d=='t') && (e=='e'))
            {
              accent = 5;
            }
            if (accent)
            {
              let |= accent;
              switch (let)
              {
                case  9 : carspe = Accents_id_agrave; break;
                case 10 : carspe = Accents_id_acirc;  break;
                case 11 : carspe = Accents_id_auml;   break;
                case 20 : carspe = Accents_id_ccedil; break;
                case 25 : carspe = Accents_id_egrave; break;
                case 29 : carspe = Accents_id_eacute; break;
                case 26 : carspe = Accents_id_ecirc;  break;
                case 27 : carspe = Accents_id_euml;   break;
                case 34 : carspe = Accents_id_icirc;  break;
                case 35 : carspe = Accents_id_iuml;   break;
                case 42 : carspe = Accents_id_ocirc;  break;
                case 43 : carspe = Accents_id_ouml;   break;
                case 49 : carspe = Accents_id_ugrave; break;
                case 50 : carspe = Accents_id_ucirc;  break;
                case 51 : carspe = Accents_id_uuml;   break;
              }
              if (carspe)
              {
                switch (accent)
                {
                  case 1 : is += 6; break;
                  case 2 : is += 5; break;
                  case 3 : is += 4; break;
                  case 4 : is += 6; break;
                  case 5 : is += 6; break;
                }
              }
            }
          }
        }
      }
    }
    if (carspe)
    {
      switch (format_cible)
      {
        case Accents_format_sans :
        {
          switch (carspe)
          {
            case Accents_id_agrave : s = (uint8_t) 'a'; break;
            case Accents_id_acirc  : s = (uint8_t) 'a'; break;
            case Accents_id_auml   : s = (uint8_t) 'a'; break;
            case Accents_id_ccedil : s = (uint8_t) 'c'; break;
            case Accents_id_egrave : s = (uint8_t) 'e'; break;
            case Accents_id_eacute : s = (uint8_t) 'e'; break;
            case Accents_id_ecirc  : s = (uint8_t) 'e'; break;
            case Accents_id_euml   : s = (uint8_t) 'e'; break;
            case Accents_id_icirc  : s = (uint8_t) 'i'; break;
            case Accents_id_iuml   : s = (uint8_t) 'i'; break;
            case Accents_id_ocirc  : s = (uint8_t) 'o'; break;
            case Accents_id_ouml   : s = (uint8_t) 'o'; break;
            case Accents_id_ugrave : s = (uint8_t) 'u'; break;
            case Accents_id_ucirc  : s = (uint8_t) 'u'; break;
            case Accents_id_uuml   : s = (uint8_t) 'u'; break;
          }
          break;
        }
        case Accents_format_ASCII :
        {
          switch (carspe)
          {
            case Accents_id_agrave : s = Accents_ASCII_agrave; break;
            case Accents_id_acirc  : s = Accents_ASCII_acirc;  break;
            case Accents_id_auml   : s = Accents_ASCII_auml;   break;
            case Accents_id_ccedil : s = Accents_ASCII_ccedil; break;
            case Accents_id_egrave : s = Accents_ASCII_egrave; break;
            case Accents_id_eacute : s = Accents_ASCII_eacute; break;
            case Accents_id_ecirc  : s = Accents_ASCII_ecirc;  break;
            case Accents_id_euml   : s = Accents_ASCII_euml;   break;
            case Accents_id_icirc  : s = Accents_ASCII_icirc;  break;
            case Accents_id_iuml   : s = Accents_ASCII_iuml;   break;
            case Accents_id_ocirc  : s = Accents_ASCII_ocirc;  break;
            case Accents_id_ouml   : s = Accents_ASCII_ouml;   break;
            case Accents_id_ugrave : s = Accents_ASCII_ugrave; break;
            case Accents_id_ucirc  : s = Accents_ASCII_ucirc;  break;
            case Accents_id_uuml   : s = Accents_ASCII_uuml;   break;
          }
          break;
        }
        case Accents_format_UTF8 :
        {
          if (id<taille_max) destination[id++] = Accents_UTF8_cle;
          //Et on continue dans le bloc dessous...
        }
        case Accents_format_UNICODE :
        {
          switch (carspe)
          {
            case Accents_id_agrave : s = Accents_UNICODE_agrave; break;
            case Accents_id_acirc  : s = Accents_UNICODE_acirc;  break;
            case Accents_id_auml   : s = Accents_UNICODE_auml;   break;
            case Accents_id_ccedil : s = Accents_UNICODE_ccedil; break;
            case Accents_id_egrave : s = Accents_UNICODE_egrave; break;
            case Accents_id_eacute : s = Accents_UNICODE_eacute; break;
            case Accents_id_ecirc  : s = Accents_UNICODE_ecirc;  break;
            case Accents_id_euml   : s = Accents_UNICODE_euml;   break;
            case Accents_id_icirc  : s = Accents_UNICODE_icirc;  break;
            case Accents_id_iuml   : s = Accents_UNICODE_iuml;   break;
            case Accents_id_ocirc  : s = Accents_UNICODE_ocirc;  break;
            case Accents_id_ouml   : s = Accents_UNICODE_ouml;   break;
            case Accents_id_ugrave : s = Accents_UNICODE_ugrave; break;
            case Accents_id_ucirc  : s = Accents_UNICODE_ucirc;  break;
            case Accents_id_uuml   : s = Accents_UNICODE_uuml;   break;
          }
          if (format_cible == Accents_format_UTF8) s &= 0b10111111; //UTF8 = UNICODE - 64
          break;
        }
        case Accents_format_HTML :
        {
          destination[id++] = Accents_HTML_cle;
          switch (carspe)
          {
            case Accents_id_agrave : let =  9; break;
            case Accents_id_acirc  : let = 10; break;
            case Accents_id_auml   : let = 11; break;
            case Accents_id_ccedil : let = 20; break;
            case Accents_id_egrave : let = 25; break;
            case Accents_id_eacute : let = 29; break;
            case Accents_id_ecirc  : let = 26; break;
            case Accents_id_euml   : let = 27; break;
            case Accents_id_icirc  : let = 34; break;
            case Accents_id_iuml   : let = 35; break;
            case Accents_id_ocirc  : let = 42; break;
            case Accents_id_ouml   : let = 43; break;
            case Accents_id_ugrave : let = 49; break;
            case Accents_id_ucirc  : let = 50; break;
            case Accents_id_uuml   : let = 51; break;
          }
          accent = let & 0b00000111;
          let &= 0b11111000;
          switch (let)
          {
            case  8 : s = (uint8_t) 'a'; break;
            case 16 : s = (uint8_t) 'c'; break;
            case 24 : s = (uint8_t) 'e'; break;
            case 32 : s = (uint8_t) 'i'; break;
            case 40 : s = (uint8_t) 'o'; break;
            case 48 : s = (uint8_t) 'u'; break;
          }
          if (id<taille_max) destination[id++] = s;
          switch (accent)
          {
            case 1 :
            {
              if (id<taille_max) destination[id++] = (uint8_t) 'g';
              if (id<taille_max) destination[id++] = (uint8_t) 'r';
              if (id<taille_max) destination[id++] = (uint8_t) 'a';
              if (id<taille_max) destination[id++] = (uint8_t) 'v';
              s = (uint8_t) 'e';
              break;
            }
            case 2 :
            {
              if (id<taille_max) destination[id++] = (uint8_t) 'c';
              if (id<taille_max) destination[id++] = (uint8_t) 'i';
              if (id<taille_max) destination[id++] = (uint8_t) 'r';
              s = (uint8_t) 'c';
              break;
            }
            case 3 :
            {
              if (id<taille_max) destination[id++] = (uint8_t) 'u';
              if (id<taille_max) destination[id++] = (uint8_t) 'm';
              s = (uint8_t) 'l';
              break;
            }
            case 4 :
            {
              if (id<taille_max) destination[id++] = (uint8_t) 'c';
              if (id<taille_max) destination[id++] = (uint8_t) 'e';
              if (id<taille_max) destination[id++] = (uint8_t) 'd';
              if (id<taille_max) destination[id++] = (uint8_t) 'i';
              s = (uint8_t) 'l';
              break;
            }
            case 5 :
            {
              if (id<taille_max) destination[id++] = (uint8_t) 'a';
              if (id<taille_max) destination[id++] = (uint8_t) 'c';
              if (id<taille_max) destination[id++] = (uint8_t) 'u';
              if (id<taille_max) destination[id++] = (uint8_t) 't';
              s = (uint8_t) 'e';
              break;
            }
          }
          break;
        }
      }
    }
    if (id<taille_max) destination[id++] = s;
    s = source[++is];
  }

  destination[id] = 0;

  return (char *) destination;
}

char* Accents_c::Supprimer(char source[], char destination[], uint8_t taille_max)
{
  return Transcoder((uint8_t *)source, (uint8_t *)destination, Accents_format_sans, taille_max);
}

char* Accents_c::Supprimer(char source_a_modifier[])
{
  return Accents_c::Supprimer(source_a_modifier, source_a_modifier, 255);
}

char* Accents_c::Transcoder_ASCII(char source[], char destination[], uint8_t taille_max)
{
  return Transcoder((uint8_t *)source, (uint8_t *)destination, Accents_format_ASCII, taille_max);
}

char* Accents_c::Transcoder_ASCII(char source_a_modifier[])
{
  return Accents_c::Transcoder_ASCII(source_a_modifier, source_a_modifier, 255);
}

char* Accents_c::Transcoder_UNICODE(char source[], char destination[], uint8_t taille_max)
{
  return Transcoder((uint8_t *)source, (uint8_t *)destination, Accents_format_UNICODE, taille_max);
}

char* Accents_c::Transcoder_UNICODE(char source_a_modifier[])
{
  return Accents_c::Transcoder_UNICODE(source_a_modifier, source_a_modifier, 255);
}

char* Accents_c::Transcoder_UTF8(char source[], char destination[], uint8_t taille_max)
{
  return Transcoder((uint8_t *)source, (uint8_t *)destination, Accents_format_UTF8, taille_max);
}

char* Accents_c::Transcoder_HTML(char source[], char destination[], uint8_t taille_max)
{
  return Transcoder((uint8_t *)source, (uint8_t *)destination, Accents_format_HTML, taille_max);
}

Accents_c Accents;
